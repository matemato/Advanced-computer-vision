import cv2
import random
import numpy as np
from numpy.fft import fft2, ifft2
import matplotlib.pyplot as plt
from ex3_utils import create_cosine_window, create_gauss_peak
from ex2_utils import get_patch, Tracker
import time
# from utils.tracker import Tracker

class MOSSETracker(Tracker):
    def __init__(self, e=1.2, s=2, a=0.15, PSR=5, t=8, n="0"):
        self.enlarge = e
        self.sigma = s
        self.alpha = a
        # self.alpha = 0.6
        self.lamb = 1e-3
        # self.scales = [0.9, 1, 1.1]
        self.scales = [1]
        self.training_images = t
        self.trans = 5
        self.rotate = 5
        self.scale = 0.1
        self.PSR = PSR
        self.n = n
        self.init = 0
        self.h2 = 0
        self.avg = 0
        self.h = 0

    def name(self):
        return self.n

    def initialize(self, image, region):
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        start = time.time()
        # print("hello")
        
        if len(region) == 8:
            x_ = np.array(region[::2])
            y_ = np.array(region[1::2])
            region = [np.min(x_), np.min(y_), np.max(x_) - np.min(x_) + 1, np.max(y_) - np.min(y_) + 1]

        self.position = [int(region[0] + region[2] / 2), int(region[1] + region[3] / 2)]
        self.patch_size = np.array([int(region[2]), int(region[3])])
        self.size = np.array([int(region[2]*self.enlarge), int(region[3]*self.enlarge)])
        if self.patch_size[0]%2==0: self.patch_size[0] += 1
        if self.patch_size[1]%2==0: self.patch_size[1] += 1
        if self.size[0]%2==0: self.size[0] += 1
        if self.size[1]%2==0: self.size[1] += 1
        
        self.win = create_cosine_window(self.size)
        self.G = create_gauss_peak(self.size, self.sigma)
 
        self.get_training_set(image)

        end = time.time()
        self.h2 += 1
        self.init += end - start
        # print("init:", 1/(end - start))
        
        # self.H_hat = (self.G_hat * np.conj(F_hat)) / (F_hat * np.conj(F_hat) + self.lamb)
        # plt.imshow(ifft2(self.H_hat).astype(float))
        # plt.show()

        # plt.imshow(ifft2(F_hat * self.H_hat).astype(float))
        # plt.show()


    def track(self, image):
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        start = time.time()
        # p,_ = get_patch(image, self.position, self.size)

        # F_hat = fft2(self.win * p)

        # plt.imshow(ifft2(F_hat).astype(float))
        # plt.show()

        # R = ifft2(self.H_hat * F_hat)

        # plt.imshow(R.astype(float))
        # plt.show()
        if len(self.scales) > 1: F_hat, R = self.get_best_size(image)
        else: 
            F_hat = self.get_F_hat(image, self.size)
            R = ifft2(self.H_hat * F_hat)

        y_shift, x_shift = np.array(np.unravel_index(R.argmax(), R.shape))
        
        if x_shift > self.size[0] / 2: x_shift -= self.size[0]
        if y_shift > self.size[1] / 2: y_shift -= self.size[1]

        self.position[0] += x_shift
        self.position[1] += y_shift

        if len(self.scales) > 1: F_hat = self.get_F_hat(image, self.patch_size)
        else: 
            F_hat = self.get_F_hat(image, self.size)

        R = ifft2(self.H_hat * F_hat)

        if(self.update(R)):

            self.A = self.alpha * fft2(self.G) * np.conj(F_hat) + (1-self.alpha) * self.A
            self.B = self.alpha * F_hat * np.conj(F_hat) + (1-self.alpha) * self.B

            self.H_hat = self.A / (self.B + self.lamb)
            # plt.imshow(ifft2(self.H_hat).real)
            # plt.show() 
        # H_hat = (self.G_hat * np.conj(F_hat)) / (F_hat * np.conj(F_hat) + self.lamb)

        # self.H_hat = (1-self.alpha) * self.H_hat + self.alpha * H_hat
        end = time.time()
        # print("track:", end - start)
        self.avg += end - start
        self.h += 1

        print(self.h / self.avg)
        print("init:",self.h2 / self.init)

        return [self.position[0] - self.patch_size[0]/2, self.position[1] - self.patch_size[1]/2, self.patch_size[0], self.patch_size[1]]

    def get_best_size(self, image):
        max_response = -np.inf
        for s in self.scales:
            if self.patch_size[0]*s > self.size[0]*2: continue
            F_hat = self.get_F_hat(image, self.patch_size*s)
            R = ifft2(self.H_hat * F_hat)
            response = np.max(R)

            # plt.imshow(ifft2(F_hat).astype(float))
            # plt.show()
            # plt.imshow(R.astype(float))
            # plt.show()

            if response > max_response:
                max_response = response
                best_F_hat = F_hat
                best_R = R
                best_scale = s
        self.patch_size = self.patch_size*best_scale
        return best_F_hat, best_R

    def get_training_set(self, image):
        rand = random.Random(1)
        p,_ = get_patch(image, self.position, self.size)
        p = np.log(p/255+1)
        p = ( p - np.mean(p) ) / np.linalg.norm(p)
        
          
        F_hat = fft2(self.win * p)
        self.A = fft2(self.G) * np.conj(F_hat) # add original image to dataset
        self.B = F_hat * np.conj(F_hat)

        if self.training_images > 0:
            for i in range(self.training_images):
                tx = rand.randint(-self.trans,self.trans)
                ty = rand.randint(-self.trans,self.trans)
                rotate_matrix = cv2.getRotationMatrix2D(center=self.size/2, angle=rand.uniform(-self.rotate, self.rotate), scale=rand.uniform(1-self.scale, 1+self.scale))
                rotated_image = cv2.warpAffine(src=p, M=rotate_matrix, dsize=self.size)
                translation_matrix = np.array([[1, 0, tx], [0, 1, ty]], dtype=np.float32)
                translated_image = cv2.warpAffine(src=rotated_image, M=translation_matrix, dsize=self.size)
                G = np.roll(self.G, (ty, tx), (0,1))
                # plt.imshow(G)
                # plt.show()
                F_hat = fft2(self.win * translated_image)
                self.A = self.alpha * fft2(G) * np.conj(F_hat) + (1-self.alpha) * self.A
                self.B = self.alpha * F_hat * np.conj(F_hat) + (1-self.alpha) * self.B
        self.H_hat = self.A / (self.B + self.lamb) 

    def update(self, R):
        G = np.roll(R.real, (int(self.size[1]/2), int(self.size[0]/2)), (0, 1))

        y, x = np.array(np.unravel_index(G.argmax(), G.shape))
        mask = np.ones([self.size[1], self.size[0]]).astype('uint8')
        left = max(0, x-11)
        top = max(0, y-11)
        right = min(x+12, self.size[0])
        bottom = min(y+12, self.size[1])
        mask[top:bottom, left:right] = 0
        mask = np.ma.make_mask(mask)
        
        
        PSR = ( np.max(G) - np.mean(G[mask]) ) / np.std(G[mask])
        # print(PSR)
        return PSR > self.PSR 

    def get_F_hat(self, image, bb):
        p,_ = get_patch(image, self.position, bb)
        # plt.imshow(p)
        # plt.show() 
        p = cv2.resize(p, self.size)
        p = np.log(p/255+1)
        p = ( p - np.mean(p) ) / np.linalg.norm(p)
        
        return fft2(self.win * p)
